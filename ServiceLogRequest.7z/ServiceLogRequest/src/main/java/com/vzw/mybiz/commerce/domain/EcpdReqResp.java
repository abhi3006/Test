package com.vzw.mybiz.commerce.domain;

import java.util.Date;

public class EcpdReqResp {

    private Integer ecpdId;
    private String sessionId;
    private String groupOrderNum;
    private Date auditDate;

    public Integer getEcpdId() {
        return ecpdId;
    }

    public void setEcpdId(Integer ecpdId) {
        this.ecpdId = ecpdId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getGroupOrderNum() {
        return groupOrderNum;
    }

    public void setGroupOrderNum(String groupOrderNum) {
        this.groupOrderNum = groupOrderNum;
    }

    public Date getAuditDate() {
        return auditDate;
    }

    public void setAuditDate(Date auditDate) {
        this.auditDate = auditDate;
    }
}
