package com.vzw.mybiz.commerce.b2b.repo;

import com.vzw.mybiz.commerce.b2b.entity.B2BOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface B2BOrderRepo extends JpaRepository<B2BOrder, Long> {
    B2BOrder findAllByReferenceNum(String orderNum);
}
