package com.vzw.mybiz.commerce.b2b.entity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "ORDER_MASTER", schema = "VOLTEB2B")
public class B2BOrderMaster implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Column(name="ID")
    private String id;
    @Column(name="ORDER_NBR")
    private String orderNbr;
    @Column(name="GROUP_ORDER_NBR")
    private String groupOrderNbr;
    @Column(name="ORDER_TYPE")
    private String orderType;
    @Column(name="ORDER_STATUS")
    private String orderStatus;
    @Column(name="ORDER_COUNT")
    private String orderCount;
    @Column(name="POS_ORDER_NR")
    private String posOrderNr;
    @Column(name="NETACE_LOCATION")
    private String netaceLocation;
    @Column(name="ECPD_ID")
    private String ecpdId;
    @Column(name="OP_CENTER")
    private String opCenter;
    @Column(name="IS_MANAGER_APPROVAL")
    private String isManagerApproval;
    @Column(name="ORDER_CHANNEL")
    private String orderChannel;
    @Column(name="ORDER_REQUEST")
    private String orderRequest;
    @Column(name="ORDER_RESPONSE")
    private String orderResponse;
    @Column(name="CREATED_BY")
    private String createdBy;
    @Column(name="CREATED_DT")
    private String createdDt;
    @Column(name="MODIFIED_BY")
    private String modifiedBy;
    @Column(name="MODIFIED_DT")
    private String modifiedDt;
    @Column(name="SERVER_INSTANCE")
    private String serverInstance;
    @Column(name="PRE_ORDER_NBR")
    private String preOrderNbr;
    @Column(name="CREDIT_APP_NBR")
    private String creditAppNbr;
    @Column(name="MULTILINE_SEQ_NBR")
    private String multilineSeqNbr;
    @Column(name="NEW_PO_NBR")
    private String newPoNbr;
    @Column(name="IP_ADDRESS")
    private String ipAddress;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }


    public String getOrderNbr() {
        return orderNbr;
    }

    public void setOrderNbr(String orderNbr) {
        this.orderNbr = orderNbr;
    }

    public String getGroupOrderNbr() {
        return groupOrderNbr;
    }

    public void setGroupOrderNbr(String groupOrderNbr) {
        this.groupOrderNbr = groupOrderNbr;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(String orderCount) {
        this.orderCount = orderCount;
    }

    public String getPosOrderNr() {
        return posOrderNr;
    }

    public void setPosOrderNr(String posOrderNr) {
        this.posOrderNr = posOrderNr;
    }

    public String getNetaceLocation() {
        return netaceLocation;
    }

    public void setNetaceLocation(String netaceLocation) {
        this.netaceLocation = netaceLocation;
    }

    public String getEcpdId() {
        return ecpdId;
    }

    public void setEcpdId(String ecpdId) {
        this.ecpdId = ecpdId;
    }

    public String getOpCenter() {
        return opCenter;
    }

    public void setOpCenter(String opCenter) {
        this.opCenter = opCenter;
    }

    public String getIsManagerApproval() {
        return isManagerApproval;
    }

    public void setIsManagerApproval(String isManagerApproval) {
        this.isManagerApproval = isManagerApproval;
    }

    public String getOrderChannel() {
        return orderChannel;
    }

    public void setOrderChannel(String orderChannel) {
        this.orderChannel = orderChannel;
    }

    public String getOrderRequest() {
        return orderRequest;
    }

    public void setOrderRequest(String orderRequest) {
        this.orderRequest = orderRequest;
    }

    public String getOrderResponse() {
        return orderResponse;
    }

    public void setOrderResponse(String orderResponse) {
        this.orderResponse = orderResponse;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(String createdDt) {
        this.createdDt = createdDt;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(String modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    public String getServerInstance() {
        return serverInstance;
    }

    public void setServerInstance(String serverInstance) {
        this.serverInstance = serverInstance;
    }

    public String getPreOrderNbr() {
        return preOrderNbr;
    }

    public void setPreOrderNbr(String preOrderNbr) {
        this.preOrderNbr = preOrderNbr;
    }

    public String getCreditAppNbr() {
        return creditAppNbr;
    }

    public void setCreditAppNbr(String creditAppNbr) {
        this.creditAppNbr = creditAppNbr;
    }

    public String getMultilineSeqNbr() {
        return multilineSeqNbr;
    }

    public void setMultilineSeqNbr(String multilineSeqNbr) {
        this.multilineSeqNbr = multilineSeqNbr;
    }

    public String getNewPoNbr() {
        return newPoNbr;
    }

    public void setNewPoNbr(String newPoNbr) {
        this.newPoNbr = newPoNbr;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }
}

