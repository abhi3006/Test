package com.vzw.mybiz.commerce.domain;

public class Customer {

    private Integer edpdId;
    private String name;

    private String userName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getEdpdId() {
        return edpdId;
    }

    public void setEdpdId(Integer edpdId) {
        this.edpdId = edpdId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
