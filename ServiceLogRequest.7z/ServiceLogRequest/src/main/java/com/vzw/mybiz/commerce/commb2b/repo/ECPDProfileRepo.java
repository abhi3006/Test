package com.vzw.mybiz.commerce.commb2b.repo;

import com.vzw.mybiz.commerce.commb2b.entity.ECPDProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ECPDProfileRepo extends JpaRepository<ECPDProfile, Long> {

    ECPDProfile findByEcpdId(Integer ecpdId);
}
