package com.vzw.mybiz.commerce.domain;

public class OrderDetails {
    public String orderNumber;
    public String posOrder;
    public String locationCode;

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getPosOrder() {
        return posOrder;
    }

    public void setPosOrder(String posOrder) {
        this.posOrder = posOrder;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }
}