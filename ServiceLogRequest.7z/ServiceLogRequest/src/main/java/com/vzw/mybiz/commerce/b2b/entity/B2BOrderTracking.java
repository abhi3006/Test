package com.vzw.mybiz.commerce.b2b.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "OPT_ORDER_TRACKING", schema = "VOLTEB2B")
public class B2BOrderTracking implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Column(name="ID")
    private String id;
    @Column(name="ORDER_NBR")
    private String orderNbr;
    @Column(name="OPT_TRANSACTION_ID")
    private String optTransactionId;
    @Column(name="OPT_STATUS")
    private String optStatus;
    @Column(name="OPT_STEP_ID")
    private String optStepId;
    @Column(name="OPT_MESSAGE")
    private String optMessage;
    @Column(name="CREATED_BY")
    private String createdBy;
    @Column(name="CREATED_DT")
    private String createdDt;
    @Column(name="MODIFIED_BY")
    private String modifiedBy;
    @Column(name="MODIFIED_DT")
    private String modifiedDt;
    @Column(name="SERVER_INSTANCE")
    private String serverInstance;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }


    public String getOrderNbr() {
        return orderNbr;
    }

    public void setOrderNbr(String orderNbr) {
        this.orderNbr = orderNbr;
    }

    public String getOptTransactionId() {
        return optTransactionId;
    }

    public void setOptTransactionId(String optTransactionId) {
        this.optTransactionId = optTransactionId;
    }

    public String getOptStatus() {
        return optStatus;
    }

    public void setOptStatus(String optStatus) {
        this.optStatus = optStatus;
    }

    public String getOptStepId() {
        return optStepId;
    }

    public void setOptStepId(String optStepId) {
        this.optStepId = optStepId;
    }

    public String getOptMessage() {
        return optMessage;
    }

    public void setOptMessage(String optMessage) {
        this.optMessage = optMessage;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(String createdDt) {
        this.createdDt = createdDt;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(String modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    public String getServerInstance() {
        return serverInstance;
    }

    public void setServerInstance(String serverInstance) {
        this.serverInstance = serverInstance;
    }
}