package com.vzw.mybiz.commerce.b2b.repo;

import com.vzw.mybiz.commerce.b2b.entity.B2BOrderMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface B2BOrderMasterRepo extends JpaRepository<B2BOrderMaster, Long> {
    B2BOrderMaster findAllByOrderNbrOrGroupOrderNbr(String orderNum, String groupOrderNum);

    B2BOrderMaster findAllByGroupOrderNbr(String groupOrderNum);
}
