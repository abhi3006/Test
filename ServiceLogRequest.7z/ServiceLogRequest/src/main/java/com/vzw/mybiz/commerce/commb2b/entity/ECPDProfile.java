package com.vzw.mybiz.commerce.commb2b.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "ECPD_PROFILE", schema = "COMMB2B")
public class ECPDProfile implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="ECPD_ID")
    private Integer ecpdId;

    @Column(name="LOGIN_METHOD")
    private Integer loginMethod;

    @Column(name="GROUP_USERNAME")
    private String groupUsername;

    @Column(name="GROUP_PASSWORD")
    private String groupPassword;

    @Column(name="URL_LOGIN")
    private String urlLogin;

    @Column(name="STATUS")
    private Integer status;

    @Column(name="NOTIFICATION_EMAIL")
    private String notificationEmail;

    @Column(name="URL_NO_LOGIN_PAGE")
    private String urlNoLoginPage;

    @Column(name="USE_URL_NO_LOGIN_PAGE")
    private Integer useUrlNoLoginPage;

    @Column(name="MANAGER_APPROVAL_VARIABLE")
    private Integer managerApprovalVariable;

    @Column(name="MANAGER_APPROVAL_STATE")
    private Integer managerApprovalState;

    @Column(name="MANAGER_APPROVAL_EMAIL_LEVEL2")
    private String managerApprovalEmailLevel2;

    @Column(name="LAST_MODIFIED")
    private Date lastModified;

    @Column(name="LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @Column(name="CREATED")
    private Date created;

    @Column(name="CREATED_BY")
    private String createdBy;

    @Column(name="DGF_ID")
    private Integer dgfId;

    @Column(name="COMPANY_NAME")
    private String companyName;

    @Column(name="ENCRYPT_KEY")
    private String encryptKey;

    @Column(name="SUPPRESS_NATIONWIDE")
    private Integer suppressNationwide;

    @Column(name="SUP_CREATE_NEW_ACCOUNT")
    private Integer supCreateNewAccount;

    @Column(name="SUP_ADD_TO_EXISTING_ACCOUNT")
    private Integer supAddToExistingAccount;

    @Column(name="AUTO_POPULATE_ACCOUNT")
    private Integer autoPopulateAccount;

    @Column(name="ACCOUNT_TO_POPULATE")
    private String accountToPopulate;

    @Column(name="EDITABLE_ACCOUNT")
    private Integer editableAccount;

    @Column(name="DISPLAY_ACCOUNT")
    private Integer displayAccount;

    @Column(name="PARENT_ECPD_ID")
    private Integer parentEcpdId;

    @Column(name="MANAGER_APPROVAL_EMAIL_LEVEL1")
    private String managerApprovalEmailLevel1;

    @Column(name="MANAGER_APPROVAL_EMAIL_LEVEL3")
    private String managerApprovalEmailLevel3;

    @Column(name="MANAGER_APPROVAL_LEVEL")
    private Integer managerApprovalLevel;

    @Column(name="ALP_EXTRA_PRAMS_ENABLED")
    private Integer alpExtraPramsEnable;


    @Column(name="COMPANY_PKG_ONLY_FLAG_OBS")
    private String companyPkgOnlyFlagObs;

    @Column(name="MA_ACCT_MAINT_STATE")
    private Integer maAcctMainState;

    @Column(name="ALP_WELCOME_MESSAGE_IND")
    private String alpWelcomeMessageInd;


    @Column(name="SUP_CREATE_NEW_ACCT_PER_LINE")
    private Integer supCreateNewAcctPreLine;

    @Column(name="IS_ALP_ENABLED")
    private String isAlpEnabled;


    @Column(name="ALP_AM_CONFIG")
    private Integer alpAmConfig;

    @Column(name="ALP_ARF")
    private Integer alpArf;

    @Column(name="ALP_CPC ")
    private Integer alpCpc;

    @Column(name="ALP_AE")
    private Integer alpAe;

    @Column(name="ALP_SUSPEND")
    private Integer alpSuspend;

    @Column(name="ALP_RESUME")
    private Integer alpResume;

    @Column(name="ALP_TRAN_HIS")
    private Integer alpTranHis;

    @Column(name="IS_VETS_ENABLED")
    private String isVetsEnabled;

    @Column(name="VETS_REMEDY_NAME")
    private String vetsRemedyName;

    public Integer getEcpdId() {
        return ecpdId;
    }

    public void setEcpdId(Integer ecpdId) {
        this.ecpdId = ecpdId;
    }

    public Integer getLoginMethod() {
        return loginMethod;
    }

    public void setLoginMethod(Integer loginMethod) {
        this.loginMethod = loginMethod;
    }

    public String getGroupUsername() {
        return groupUsername;
    }

    public void setGroupUsername(String groupUsername) {
        this.groupUsername = groupUsername;
    }

    public String getGroupPassword() {
        return groupPassword;
    }

    public void setGroupPassword(String groupPassword) {
        this.groupPassword = groupPassword;
    }

    public String getUrlLogin() {
        return urlLogin;
    }

    public void setUrlLogin(String urlLogin) {
        this.urlLogin = urlLogin;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getNotificationEmail() {
        return notificationEmail;
    }

    public void setNotificationEmail(String notificationEmail) {
        this.notificationEmail = notificationEmail;
    }

    public String getUrlNoLoginPage() {
        return urlNoLoginPage;
    }

    public void setUrlNoLoginPage(String urlNoLoginPage) {
        this.urlNoLoginPage = urlNoLoginPage;
    }

    public Integer getUseUrlNoLoginPage() {
        return useUrlNoLoginPage;
    }

    public void setUseUrlNoLoginPage(Integer useUrlNoLoginPage) {
        this.useUrlNoLoginPage = useUrlNoLoginPage;
    }

    public Integer getManagerApprovalVariable() {
        return managerApprovalVariable;
    }

    public void setManagerApprovalVariable(Integer managerApprovalVariable) {
        this.managerApprovalVariable = managerApprovalVariable;
    }

    public Integer getManagerApprovalState() {
        return managerApprovalState;
    }

    public void setManagerApprovalState(Integer managerApprovalState) {
        this.managerApprovalState = managerApprovalState;
    }

    public String getManagerApprovalEmailLevel2() {
        return managerApprovalEmailLevel2;
    }

    public void setManagerApprovalEmailLevel2(String managerApprovalEmailLevel2) {
        this.managerApprovalEmailLevel2 = managerApprovalEmailLevel2;
    }

    public Date getLastModified() {
        return lastModified;
    }

    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getDgfId() {
        return dgfId;
    }

    public void setDgfId(Integer dgfId) {
        this.dgfId = dgfId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getEncryptKey() {
        return encryptKey;
    }

    public void setEncryptKey(String encryptKey) {
        this.encryptKey = encryptKey;
    }

    public Integer getSuppressNationwide() {
        return suppressNationwide;
    }

    public void setSuppressNationwide(Integer suppressNationwide) {
        this.suppressNationwide = suppressNationwide;
    }

    public Integer getSupCreateNewAccount() {
        return supCreateNewAccount;
    }

    public void setSupCreateNewAccount(Integer supCreateNewAccount) {
        this.supCreateNewAccount = supCreateNewAccount;
    }

    public Integer getSupAddToExistingAccount() {
        return supAddToExistingAccount;
    }

    public void setSupAddToExistingAccount(Integer supAddToExistingAccount) {
        this.supAddToExistingAccount = supAddToExistingAccount;
    }

    public Integer getAutoPopulateAccount() {
        return autoPopulateAccount;
    }

    public void setAutoPopulateAccount(Integer autoPopulateAccount) {
        this.autoPopulateAccount = autoPopulateAccount;
    }

    public String getAccountToPopulate() {
        return accountToPopulate;
    }

    public void setAccountToPopulate(String accountToPopulate) {
        this.accountToPopulate = accountToPopulate;
    }

    public Integer getEditableAccount() {
        return editableAccount;
    }

    public void setEditableAccount(Integer editableAccount) {
        this.editableAccount = editableAccount;
    }

    public Integer getDisplayAccount() {
        return displayAccount;
    }

    public void setDisplayAccount(Integer displayAccount) {
        this.displayAccount = displayAccount;
    }

    public Integer getParentEcpdId() {
        return parentEcpdId;
    }

    public void setParentEcpdId(Integer parentEcpdId) {
        this.parentEcpdId = parentEcpdId;
    }

    public String getManagerApprovalEmailLevel1() {
        return managerApprovalEmailLevel1;
    }

    public void setManagerApprovalEmailLevel1(String managerApprovalEmailLevel1) {
        this.managerApprovalEmailLevel1 = managerApprovalEmailLevel1;
    }

    public String getManagerApprovalEmailLevel3() {
        return managerApprovalEmailLevel3;
    }

    public void setManagerApprovalEmailLevel3(String managerApprovalEmailLevel3) {
        this.managerApprovalEmailLevel3 = managerApprovalEmailLevel3;
    }

    public Integer getManagerApprovalLevel() {
        return managerApprovalLevel;
    }

    public void setManagerApprovalLevel(Integer managerApprovalLevel) {
        this.managerApprovalLevel = managerApprovalLevel;
    }

    public Integer getAlpExtraPramsEnable() {
        return alpExtraPramsEnable;
    }

    public void setAlpExtraPramsEnable(Integer alpExtraPramsEnable) {
        this.alpExtraPramsEnable = alpExtraPramsEnable;
    }

    public String getCompanyPkgOnlyFlagObs() {
        return companyPkgOnlyFlagObs;
    }

    public void setCompanyPkgOnlyFlagObs(String companyPkgOnlyFlagObs) {
        this.companyPkgOnlyFlagObs = companyPkgOnlyFlagObs;
    }

    public Integer getMaAcctMainState() {
        return maAcctMainState;
    }

    public void setMaAcctMainState(Integer maAcctMainState) {
        this.maAcctMainState = maAcctMainState;
    }

    public String getAlpWelcomeMessageInd() {
        return alpWelcomeMessageInd;
    }

    public void setAlpWelcomeMessageInd(String alpWelcomeMessageInd) {
        this.alpWelcomeMessageInd = alpWelcomeMessageInd;
    }

    public Integer getSupCreateNewAcctPreLine() {
        return supCreateNewAcctPreLine;
    }

    public void setSupCreateNewAcctPreLine(Integer supCreateNewAcctPreLine) {
        this.supCreateNewAcctPreLine = supCreateNewAcctPreLine;
    }

    public String getIsAlpEnabled() {
        return isAlpEnabled;
    }

    public void setIsAlpEnabled(String isAlpEnabled) {
        this.isAlpEnabled = isAlpEnabled;
    }

    public Integer getAlpAmConfig() {
        return alpAmConfig;
    }

    public void setAlpAmConfig(Integer alpAmConfig) {
        this.alpAmConfig = alpAmConfig;
    }

    public Integer getAlpArf() {
        return alpArf;
    }

    public void setAlpArf(Integer alpArf) {
        this.alpArf = alpArf;
    }

    public Integer getAlpCpc() {
        return alpCpc;
    }

    public void setAlpCpc(Integer alpCpc) {
        this.alpCpc = alpCpc;
    }

    public Integer getAlpAe() {
        return alpAe;
    }

    public void setAlpAe(Integer alpAe) {
        this.alpAe = alpAe;
    }

    public Integer getAlpSuspend() {
        return alpSuspend;
    }

    public void setAlpSuspend(Integer alpSuspend) {
        this.alpSuspend = alpSuspend;
    }

    public Integer getAlpResume() {
        return alpResume;
    }

    public void setAlpResume(Integer alpResume) {
        this.alpResume = alpResume;
    }

    public Integer getAlpTranHis() {
        return alpTranHis;
    }

    public void setAlpTranHis(Integer alpTranHis) {
        this.alpTranHis = alpTranHis;
    }

    public String getIsVetsEnabled() {
        return isVetsEnabled;
    }

    public void setIsVetsEnabled(String isVetsEnabled) {
        this.isVetsEnabled = isVetsEnabled;
    }

    public String getVetsRemedyName() {
        return vetsRemedyName;
    }

    public void setVetsRemedyName(String vetsRemedyName) {
        this.vetsRemedyName = vetsRemedyName;
    }
}
