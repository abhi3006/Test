package com.vzw.mybiz.commerce.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.HashMap;

@Configuration
@EnableTransactionManagement
@EnableConfigurationProperties(B2BDataSourceConfig.class)
@EnableJpaRepositories(basePackages = {"com.vzw.mybiz.commerce.b2b.repo"}, entityManagerFactoryRef = "b2bEntityManager", transactionManagerRef = "b2bTransactionManager")
@EntityScan(basePackages = {"com.vzw.mybiz.commerce.b2b.entity"})
public class B2BDataConnectionConfig {

    @Autowired
    B2BDataSourceConfig dataSourceConfig;

    @Bean
    public DataSource b2bDataSource() {
        HikariDataSource hikariDataSource = new HikariDataSource();
        hikariDataSource.setDriverClassName(dataSourceConfig.getDriverClassName());
        hikariDataSource.setJdbcUrl(dataSourceConfig.getUrl());
        hikariDataSource.setUsername(dataSourceConfig.getUserName());
        hikariDataSource.setPassword(dataSourceConfig.getEncryptedPassword());
        hikariDataSource.setMaximumPoolSize(dataSourceConfig.getHikari().getMaximumPoolSize());
        hikariDataSource.setPoolName(dataSourceConfig.getHikari().getPoolName());
        hikariDataSource.setMinimumIdle(dataSourceConfig.getHikari().getMinimumIdle());
        hikariDataSource.setAutoCommit(dataSourceConfig.getHikari().isAutoCommit());
        hikariDataSource.setMaxLifetime(dataSourceConfig.getHikari().getMaxLifetime());
        hikariDataSource.setConnectionTimeout(dataSourceConfig.getHikari().getConnectionTimeout());

        return hikariDataSource;
    }


    @Bean(name = "b2bEntityManager")
    public EntityManagerFactory b2bEntityManager() {

        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(b2bDataSource());
        em.setPackagesToScan(new String[]{"com.vzw.mybiz.commerce.b2b.entity"});

        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        em.setPersistenceUnitName("datasourcevolteb2b");
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect", "org.hibernate.dialect.Oracle12cDialect");
        em.setJpaPropertyMap(properties);
        em.afterPropertiesSet();
        return em.getObject();

    }

    @Bean(name = "b2bTransactionManager")
    public PlatformTransactionManager transactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(b2bEntityManager());
        return transactionManager;
    }

}
