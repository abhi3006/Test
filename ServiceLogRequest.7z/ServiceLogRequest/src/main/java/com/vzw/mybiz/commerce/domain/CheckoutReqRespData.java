package com.vzw.mybiz.commerce.domain;

import java.util.Date;

public class CheckoutReqRespData {

    private String service;
    private String uri;
    private String transactionType;
    private String externalSys;
    private String transactionstatus;
    private Object reqPayload;

    private String span;

    private String parentSpan;

    public String getSpan() {
        return span;
    }

    public void setSpan(String span) {
        this.span = span;
    }

    public String getParentSpan() {
        return parentSpan;
    }

    public void setParentSpan(String parentSpan) {
        this.parentSpan = parentSpan;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getExternalSys() {
        return externalSys;
    }

    public void setExternalSys(String externalSys) {
        this.externalSys = externalSys;
    }

    private String respPayload;
    private Long timeTaken;
    private String sessionId;
    private Date auditCreateDt;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getTransactionstatus() {
        return transactionstatus;
    }

    public void setTransactionstatus(String transactionstatus) {
        this.transactionstatus = transactionstatus;
    }

    public Object getReqPayload() {
        return reqPayload;
    }

    public void setReqPayload(Object reqPayload) {
        this.reqPayload = reqPayload;
    }

    public String getRespPayload() {
        return respPayload;
    }

    public void setRespPayload(String respPayload) {
        this.respPayload = respPayload;
    }

    public Long getTimeTaken() {
        return timeTaken;
    }

    public void setTimeTaken(Long timeTaken) {
        this.timeTaken = timeTaken;
    }


    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Date getAuditCreateDt() {
        return auditCreateDt;
    }

    public void setAuditCreateDt(Date auditCreateDt) {
        this.auditCreateDt = auditCreateDt;
    }
}
