package com.vzw.mybiz.commerce.domain;

import java.util.ArrayList;

public class EcpdServiceResp {

    public int totalElements;
    public int pageSize;
    public int totalPages;
    public int currentPageNo;
    public ArrayList<EcpdReqResp> reqRespData;


    public int getTotalElements() {
        return totalElements;
    }

    public void setTotalElements(int totalElements) {
        this.totalElements = totalElements;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public int getCurrentPageNo() {
        return currentPageNo;
    }

    public void setCurrentPageNo(int currentPageNo) {
        this.currentPageNo = currentPageNo;
    }

    public ArrayList<EcpdReqResp> getReqRespData() {
        return reqRespData;
    }

    public void setReqRespData(ArrayList<EcpdReqResp> reqRespData) {
        this.reqRespData = reqRespData;
    }
}
