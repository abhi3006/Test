package com.vzw.mybiz.commerce.domain;

import java.util.ArrayList;

public class CheckoutServiceResponse {

    private int totalElements;
    private int pageSize;
    private int totalPages;
    private int currentPageNo;
    private Customer customer;
    private ArrayList<CheckoutReqRespData> reqRespData;

    public int getTotalElements() {
        return totalElements;
    }

    public void setTotalElements(int totalElements) {
        this.totalElements = totalElements;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public int getCurrentPageNo() {
        return currentPageNo;
    }

    public void setCurrentPageNo(int currentPageNo) {
        this.currentPageNo = currentPageNo;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public ArrayList<CheckoutReqRespData> getReqRespData() {
        return reqRespData;
    }

    public void setReqRespData(ArrayList<CheckoutReqRespData> reqRespData) {
        this.reqRespData = reqRespData;
    }
}
