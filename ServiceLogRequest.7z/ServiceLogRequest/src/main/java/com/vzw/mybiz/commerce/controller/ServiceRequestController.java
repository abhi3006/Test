package com.vzw.mybiz.commerce.controller;


import com.vzw.mybiz.commerce.domain.*;
import com.vzw.mybiz.commerce.service.CommerceAssistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


//@RequestMapping("log")
@Controller
@CrossOrigin
public class ServiceRequestController {
	@Autowired
	private CommerceAssistService commerceAssistService;


	@PostMapping("/getActivationJourney")
	public ResponseEntity<ActivationServiceResponse> postServiceRegistry(@RequestBody ActivationServiceRequest request) {

		return commerceAssistService.invokeActivationService(request);
	}


	@PostMapping("/getAutomationJourney")
	public ResponseEntity<AutomationServiceResponse> postServiceRegistry(@RequestBody AutomationServiceRequest request) {

		return commerceAssistService.invokeAutomationService(request);
	}


	@PostMapping("/getCheckoutJourney")
	public ResponseEntity<CheckoutServiceResponse> postServiceRegistry(@RequestBody CheckoutServiceRequest request) {

		return commerceAssistService.invokeCheckoutService(request);
	}

	@PostMapping("/getEcpdId")
	public ResponseEntity<EcpdServiceResp> postServiceRegistry(@RequestBody EcpdServiceReq request) {

		return commerceAssistService.invokeEcpdId(request);
	}

}