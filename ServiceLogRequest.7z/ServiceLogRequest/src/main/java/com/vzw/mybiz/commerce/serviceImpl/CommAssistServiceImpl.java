package com.vzw.mybiz.commerce.serviceImpl;

import com.vzw.mybiz.commerce.b2b.entity.B2BOrder;
import com.vzw.mybiz.commerce.b2b.entity.B2BOrderMaster;
import com.vzw.mybiz.commerce.b2b.entity.B2BOrderTracking;
import com.vzw.mybiz.commerce.b2b.repo.B2BOrderMasterRepo;
import com.vzw.mybiz.commerce.b2b.repo.B2BOrderRepo;
import com.vzw.mybiz.commerce.b2b.repo.B2BOrderTrackingRepo;
import com.vzw.mybiz.commerce.commb2b.entity.ECPDProfile;
import com.vzw.mybiz.commerce.commb2b.repo.ECPDProfileRepo;
import com.vzw.mybiz.commerce.commtrans.entity.CommReqResp;
import com.vzw.mybiz.commerce.commtrans.repo.CommReqRepsRepo;
import com.vzw.mybiz.commerce.domain.*;
import com.vzw.mybiz.commerce.service.CommerceAssistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class CommAssistServiceImpl implements CommerceAssistService {

    @Autowired
    B2BOrderMasterRepo b2BOrderMasterRepo;

    @Autowired
    B2BOrderRepo b2BOrderRepo;

    @Autowired
    B2BOrderTrackingRepo b2BOrderTrackingRepo;

    @Autowired
    CommReqRepsRepo commReqRepsRepo;

    @Autowired
    ECPDProfileRepo ecpdProfileRepo;

    @Override
    public ResponseEntity<ActivationServiceResponse> invokeActivationService(ActivationServiceRequest request) {

        String groupOrderNum = request.getGroupOrderNum();
        String sessionId = request.getSessionId();
        String orderNum = request.getOrderNum();
        B2BOrder b2BOrder = null;
        ActivationServiceResponse activationServiceResponse = new ActivationServiceResponse();
        if (groupOrderNum != null && orderNum == null) {
            B2BOrderMaster b2BOrderMaster = b2BOrderMasterRepo.findAllByGroupOrderNbr(groupOrderNum);
            orderNum = b2BOrderMaster.getOrderNbr();
        }
        if (orderNum != null) {
            b2BOrder = b2BOrderRepo.findAllByReferenceNum(orderNum);
        }
        activationServiceResponse.setOrderStatus(b2BOrder.getOrderStatus());
        activationServiceResponse.setPosOrderStatus("");
        activationServiceResponse.setWfmOrderStatus("");

        return new ResponseEntity<>(activationServiceResponse, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<AutomationServiceResponse> invokeAutomationService(AutomationServiceRequest request) {

        Pageable paging = PageRequest.of(request.getPageNo(), request.getPageSize());
        String groupOrderNum = request.getGroupOrderNum();
        String sessionId = request.getSessionId();
        String orderNum = request.getOrderNum();
        OrderDetails orderDetails = new OrderDetails();
        List<SubmitWorkFlow> submitWorkFlowList = new ArrayList<SubmitWorkFlow>();
        AutomationServiceResponse automationServiceResponse = new AutomationServiceResponse();
        try {
            /*
             * To do logic for session_id
             *
             * */
            if (orderNum != null || sessionId != null || groupOrderNum != null) {
                B2BOrderMaster b2bOrderMaster = b2BOrderMasterRepo.findAllByOrderNbrOrGroupOrderNbr(orderNum, groupOrderNum);
                if (b2bOrderMaster.getOrderNbr() != null) {
                    orderDetails.setOrderNumber(b2bOrderMaster.getOrderNbr());
                    orderDetails.setPosOrder(b2bOrderMaster.getPosOrderNr());
                    orderDetails.setLocationCode(b2bOrderMaster.getNetaceLocation());
                    automationServiceResponse.setOrderDetails(orderDetails);

                    Page<B2BOrderTracking> b2BOrderTrackingList = b2BOrderTrackingRepo.findAllByOrderNbr(b2bOrderMaster.getOrderNbr(), paging);

                    if (b2BOrderTrackingList.hasNext()) {
                        for (B2BOrderTracking b2BOrderTracking : b2BOrderTrackingList) {
                            SubmitWorkFlow submitWorkFlow = new SubmitWorkFlow();
                            submitWorkFlow.setOptStepId(b2BOrderTracking.getOptStepId());
                            submitWorkFlow.setOptMessage(b2BOrderTracking.getOptMessage());
                            submitWorkFlow.setOptStatus(b2BOrderTracking.getOptStatus());
                            submitWorkFlow.setCreatedBy(b2BOrderTracking.getCreatedBy());
                            submitWorkFlow.setServerInstance(b2BOrderTracking.getServerInstance());
                            submitWorkFlow.setCreatedDate(b2BOrderTracking.getCreatedDt());
                            submitWorkFlowList.add(submitWorkFlow);
                        }

                        automationServiceResponse.setTotalElements(b2BOrderTrackingList.getNumberOfElements());
                        automationServiceResponse.setPageSize(b2BOrderTrackingList.getSize());
                        automationServiceResponse.setTotalPages(b2BOrderTrackingList.getTotalPages());
                        automationServiceResponse.setCurrentPageNo(b2BOrderTrackingList.getNumber());
                        automationServiceResponse.setSubmitWorkFlow((ArrayList<SubmitWorkFlow>) submitWorkFlowList);
                    }
                } else {
                    System.out.println("error: No order found");  //replace with logger
                }
            }
        } catch (Exception ex) {
            ex.getStackTrace();

        }
        return new ResponseEntity<>(automationServiceResponse, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<CheckoutServiceResponse> invokeCheckoutService(CheckoutServiceRequest request) {

        Pageable paging = PageRequest.of(request.getPageNo(), request.getPageSize());
        String groupOrderNum = request.getGroupOrderNum();
        String sessionId = request.getSessionId();
        String orderNum = request.getOrderNum();
        Customer customer = new Customer();
        List<CheckoutReqRespData> checkoutReqRespData = new ArrayList<>();
        CheckoutServiceResponse checkoutServiceResponse = new CheckoutServiceResponse();

        try {
            if (orderNum != null || sessionId != null || groupOrderNum != null) {
                CommReqResp commReqResp = commReqRepsRepo.findFirstByCorrelationId(groupOrderNum);
                ECPDProfile ecpdProfile = ecpdProfileRepo.findByEcpdId(commReqResp.getEcpdId());
                customer.setEdpdId(commReqResp.getEcpdId());
                customer.setName(ecpdProfile.getCompanyName());

                 List<CommReqResp> commReqRespList = commReqRepsRepo.findAllByCorrelationIdOrderByAuditCreateDt(groupOrderNum);
              //Page<CommReqResp> commReqRespList = commReqRepsRepo.findTop20ByCorrelationIdOrderByAuditCreateDt(groupOrderNum, paging);

                if (commReqRespList!=null) {
                    for (CommReqResp commReqRespDb : commReqRespList) {
                            CheckoutReqRespData checkoutRequestResponseData = new CheckoutReqRespData();
                        checkoutRequestResponseData.setService(commReqRespDb.getService());
                        checkoutRequestResponseData.setUri(commReqRespDb.getUri());
                        if (commReqRespDb.getExternalSys() != null || "NA".equalsIgnoreCase(commReqRespDb.getExternalSys())) {
                            checkoutRequestResponseData.setTransactionType("Internal");
                            checkoutRequestResponseData.setExternalSys("");
                        } else {
                            checkoutRequestResponseData.setTransactionType("External");
                            checkoutRequestResponseData.setExternalSys(commReqRespDb.getExternalSys());
                        }
                        checkoutRequestResponseData.setTransactionstatus(commReqRespDb.getMessageDesc());
                        checkoutRequestResponseData.setRespPayload(commReqRespDb.getRespPayload());
                        checkoutRequestResponseData.setReqPayload(commReqRespDb.getReqPayload());
                        checkoutRequestResponseData.setTimeTaken(commReqRespDb.getTimeTaken());
                     //   checkoutRequestResponseData.setUserName(commReqRespDb.getUserName());
                        customer.setUserName(commReqRespDb.getUserName());
                        checkoutRequestResponseData.setSessionId(commReqRespDb.getSessionId());
                        checkoutRequestResponseData.setAuditCreateDt(commReqRespDb.getAuditCreateDt());
                        checkoutRequestResponseData.setSpan(commReqRespDb.getSpan());
                        checkoutRequestResponseData.setParentSpan(commReqRespDb.getParentSpan());
                        checkoutReqRespData.add(checkoutRequestResponseData);
                    }
                    checkoutServiceResponse.setCustomer(customer);
                    /*checkoutServiceResponse.setTotalElements(commReqRespList.getNumberOfElements());
                    checkoutServiceResponse.setPageSize(commReqRespList.getSize());
                    checkoutServiceResponse.setTotalPages(commReqRespList.getTotalPages());
                    checkoutServiceResponse.setCurrentPageNo(commReqRespList.getNumber());*/
                    checkoutServiceResponse.setReqRespData((ArrayList<CheckoutReqRespData>) checkoutReqRespData);
                }

            } else {
                System.out.println("error: No order found");  //replace with logger
            }
        } catch (Exception ex) {
            ex.getStackTrace();
        }
        return new ResponseEntity<>(checkoutServiceResponse, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<EcpdServiceResp> invokeEcpdId(EcpdServiceReq request) {

        Pageable paging = PageRequest.of(request.getPageNo(), request.getPageSize());
        Integer ecpdid = request.getEcpdId();
        String startdate = request.getStartDate();
        String enddate = request.getEndDate();
        List<EcpdReqResp> ecpdServiceReqs = new ArrayList<EcpdReqResp>();
        EcpdServiceResp ecpdServiceResp = new EcpdServiceResp();
        try{
            if(ecpdid!=null){
                Page<CommReqResp> commReqRespList = commReqRepsRepo.findByEcpdId(ecpdid, paging);
                if(commReqRespList.hasNext()){
                    for (CommReqResp commReqRespDb : commReqRespList){
                        EcpdReqResp ecpdReqResp = new EcpdReqResp();
                        ecpdReqResp.setEcpdId(commReqRespDb.getEcpdId());
                        ecpdReqResp.setSessionId(commReqRespDb.getSessionId());
                        ecpdReqResp.setGroupOrderNum(commReqRespDb.getCorrelationId());
                        ecpdReqResp.setAuditDate(commReqRespDb.getAuditCreateDt());
                        ecpdServiceReqs.add(ecpdReqResp);
                    }
                }
                ecpdServiceResp.setTotalElements(commReqRespList.getNumberOfElements());
                ecpdServiceResp.setPageSize(commReqRespList.getSize());
                ecpdServiceResp.setTotalPages(commReqRespList.getTotalPages());
                ecpdServiceResp.setCurrentPageNo(commReqRespList.getNumber());
                ecpdServiceResp.setReqRespData((ArrayList<EcpdReqResp>) ecpdServiceReqs);
            }
        }
        catch (Exception ex){
            ex.getStackTrace();
        }
        return new ResponseEntity<>(ecpdServiceResp, HttpStatus.OK);
    }
}
