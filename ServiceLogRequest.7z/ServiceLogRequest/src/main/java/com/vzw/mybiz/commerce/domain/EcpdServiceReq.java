package com.vzw.mybiz.commerce.domain;

public class EcpdServiceReq {

    private Integer ecpdId;
    private String startDate;
    private String endDate;

    private Integer pageNo;

    private Integer pageSize;


    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getEcpdId() {
        return ecpdId;
    }

    public void setEcpdId(Integer ecpdId) {
        this.ecpdId = ecpdId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
