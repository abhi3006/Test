package com.vzw.mybiz.commerce.service;

import com.vzw.mybiz.commerce.domain.*;
import org.springframework.http.ResponseEntity;


public interface CommerceAssistService {
     
     ResponseEntity<ActivationServiceResponse> invokeActivationService(ActivationServiceRequest request);

     ResponseEntity<AutomationServiceResponse> invokeAutomationService(AutomationServiceRequest request);

     ResponseEntity<CheckoutServiceResponse> invokeCheckoutService(CheckoutServiceRequest request);

     ResponseEntity<EcpdServiceResp> invokeEcpdId(EcpdServiceReq request);
}
