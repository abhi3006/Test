package com.vzw.mybiz.commerce.domain;

public class CheckoutServiceRequest {
    private String groupOrderNum;
    private String sessionId;
    private String orderNum;
    private Integer pageNo;

    private Integer pageSize;


    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getGroupOrderNum() {
        return groupOrderNum;
    }

    public void setGroupOrderNum(String groupOrderNum) {
        this.groupOrderNum = groupOrderNum;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }
}
