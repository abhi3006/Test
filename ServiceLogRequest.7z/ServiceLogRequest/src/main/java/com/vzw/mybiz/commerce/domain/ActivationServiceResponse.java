package com.vzw.mybiz.commerce.domain;

public class ActivationServiceResponse {

    private String orderStatus;
    private String posOrderStatus;
    private String wfmOrderStatus;

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getPosOrderStatus() {
        return posOrderStatus;
    }

    public void setPosOrderStatus(String posOrderStatus) {
        this.posOrderStatus = posOrderStatus;
    }

    public String getWfmOrderStatus() {
        return wfmOrderStatus;
    }

    public void setWfmOrderStatus(String wfmOrderStatus) {
        this.wfmOrderStatus = wfmOrderStatus;
    }
}
