package com.vzw.mybiz.commerce.b2b.repo;

import com.vzw.mybiz.commerce.b2b.entity.B2BOrderTracking;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface B2BOrderTrackingRepo extends JpaRepository<B2BOrderTracking, Long> {
    Page<B2BOrderTracking> findAllByOrderNbr(String orderNbr, Pageable pageable);
}
