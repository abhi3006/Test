package com.vzw.mybiz.commerce.commtrans.repo;

import com.vzw.mybiz.commerce.commtrans.entity.CommReqResp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface CommReqRepsRepo extends CrudRepository<CommReqResp, Long> {


    CommReqResp findFirstByCorrelationId(String groupOrderNum);

   // List<CommReqResp> findAllByCorrelationId(String groupOrderNum);

    List<CommReqResp> findTop20ByCorrelationIdOrderByAuditCreateDt(String groupOrderNum);

    Page<CommReqResp> findByEcpdId(Integer ecpdid, Pageable paging);

    List<CommReqResp> findAllByCorrelationIdOrderByAuditCreateDt(String groupOrderNum);
}
