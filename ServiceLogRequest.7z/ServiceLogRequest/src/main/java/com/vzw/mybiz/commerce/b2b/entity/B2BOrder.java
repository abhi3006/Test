package com.vzw.mybiz.commerce.b2b.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "B2B_ORDER", schema = "VOLTEB2B")
public class B2BOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name="ECPD_ID")
    private String ecpdId;

    @Id
    @Column(name="REFERENCE_NUM")
    private String referenceNum;

    @Column(name="BILLING_SYS_ACCT_NO")
    private String billingSysAcctNo;

    @Column(name="SUBMITTER_USER_ID")
    private String submitterUserId;

    @Column(name="ORDER_TYPE")
    private String orderType;

    @Column(name="ORDER_STATUS")
    private String orderStatus;

    @Column(name="COURIER_TRACKING_NUM")
    private String couruerTrackingNum;

    @Column(name="COURIER_TRACKING_NUM1")
    private String couruerTrackingNum1;

    @Column(name="LOCATION_CD")
    private String locationCd;

    @Column(name="SOURCE")
    private String source;

    @Column(name="MDN")
    private String mdn;

    @Column(name="PRODUCT_NAME")
    private String productName;

    @Column(name="SYSTEM")
    private String system;

    @Column(name="SERVICE_LOCATION")
    private String serviceLocation;

    @Column(name="ADDRESS_LINE1")
    private String addressLine1;

    @Column(name="ADDRESS_LINE2")
    private String addressLine2;

    @Column(name="CITY")
    private String city;

    @Column(name="STATE")
    private String state;

    @Column(name="ZIPCODE")
    private String zipCode;

    @Column(name="ORDER_ID")
    private String orderId;

    @Column(name="ORDER_COMP_AUTO")
    private String orderCompAuto;

    @Column(name="ORDER_ERROR_MESSAGE")
    private String orderErrorMessage;

    @Column(name="BULK_ORDER_REFERENCE_NO")
    private String bulkOrderRefferenceNo;

    @Column(name="ACE_ORDER_NUM")
    private String aceOrderNum;

    @Column(name="IMPERSONATION_FIRST_NAME")
    private String impersonationFirstName;

    @Column(name="IMPERSONATION_Last_NAME")
    private String impersonationLastName;

    @Column(name="ENTERED_DT")
    private Date enteredDt;

    @Column(name="LAST_UPDATED_DT")
    private Date lastUpdatedDt;

    public String getEcpdId() {
        return ecpdId;
    }

    public void setEcpdId(String ecpdId) {
        this.ecpdId = ecpdId;
    }

    public String getReferenceNum() {
        return referenceNum;
    }

    public void setReferenceNum(String referenceNum) {
        this.referenceNum = referenceNum;
    }

    public String getBillingSysAcctNo() {
        return billingSysAcctNo;
    }

    public void setBillingSysAcctNo(String billingSysAcctNo) {
        this.billingSysAcctNo = billingSysAcctNo;
    }

    public String getSubmitterUserId() {
        return submitterUserId;
    }

    public void setSubmitterUserId(String submitterUserId) {
        this.submitterUserId = submitterUserId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getCouruerTrackingNum() {
        return couruerTrackingNum;
    }

    public void setCouruerTrackingNum(String couruerTrackingNum) {
        this.couruerTrackingNum = couruerTrackingNum;
    }

    public String getCouruerTrackingNum1() {
        return couruerTrackingNum1;
    }

    public void setCouruerTrackingNum1(String couruerTrackingNum1) {
        this.couruerTrackingNum1 = couruerTrackingNum1;
    }

    public String getLocationCd() {
        return locationCd;
    }

    public void setLocationCd(String locationCd) {
        this.locationCd = locationCd;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getMdn() {
        return mdn;
    }

    public void setMdn(String mdn) {
        this.mdn = mdn;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    public String getServiceLocation() {
        return serviceLocation;
    }

    public void setServiceLocation(String serviceLocation) {
        this.serviceLocation = serviceLocation;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderCompAuto() {
        return orderCompAuto;
    }

    public void setOrderCompAuto(String orderCompAuto) {
        this.orderCompAuto = orderCompAuto;
    }

    public String getOrderErrorMessage() {
        return orderErrorMessage;
    }

    public void setOrderErrorMessage(String orderErrorMessage) {
        this.orderErrorMessage = orderErrorMessage;
    }

    public String getBulkOrderRefferenceNo() {
        return bulkOrderRefferenceNo;
    }

    public void setBulkOrderRefferenceNo(String bulkOrderRefferenceNo) {
        this.bulkOrderRefferenceNo = bulkOrderRefferenceNo;
    }

    public String getAceOrderNum() {
        return aceOrderNum;
    }

    public void setAceOrderNum(String aceOrderNum) {
        this.aceOrderNum = aceOrderNum;
    }

    public String getImpersonationFirstName() {
        return impersonationFirstName;
    }

    public void setImpersonationFirstName(String impersonationFirstName) {
        this.impersonationFirstName = impersonationFirstName;
    }

    public String getImpersonationLastName() {
        return impersonationLastName;
    }

    public void setImpersonationLastName(String impersonationLastName) {
        this.impersonationLastName = impersonationLastName;
    }

    public Date getEnteredDt() {
        return enteredDt;
    }

    public void setEnteredDt(Date enteredDt) {
        this.enteredDt = enteredDt;
    }

    public Date getLastUpdatedDt() {
        return lastUpdatedDt;
    }

    public void setLastUpdatedDt(Date lastUpdatedDt) {
        this.lastUpdatedDt = lastUpdatedDt;
    }
}
